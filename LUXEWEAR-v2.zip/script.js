const products = [
  {id:1,name:"Classic Black Jacket",category:"men",label:"MEN'S CLOTHING",price:89.99,oldPrice:119.99,rating:"★★★★★",reviews:42,badge:"SALE",newArrival:false,colors:["#111","#777"],image:"https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=700&q=85",description:"A sharp everyday jacket with a clean silhouette and versatile finish."},
  {id:2,name:"Elegant White Dress",category:"women",label:"WOMEN'S CLOTHING",price:74.99,rating:"★★★★★",reviews:68,badge:"NEW",newArrival:true,colors:["#fff","#111"],image:"https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=700&q=85",description:"A refined dress designed for effortless elegance from day to evening."},
  {id:3,name:"Urban Sneakers",category:"shoes",label:"FOOTWEAR",price:64.99,rating:"★★★★☆",reviews:31,badge:"NEW",newArrival:true,colors:["#d22","#111","#fff"],image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=85",description:"Comfortable street-ready sneakers with a bold modern profile."},
  {id:4,name:"Premium White Shirt",category:"men",label:"MEN'S CLOTHING",price:49.99,rating:"★★★★★",reviews:87,badge:"",newArrival:false,colors:["#fff","#111"],image:"https://images.unsplash.com/photo-1603252110481-7ba873bf42ab?auto=format&fit=crop&w=700&q=85",description:"A timeless wardrobe essential with a crisp, premium look."},
  {id:5,name:"Modern Beige Coat",category:"women",label:"WOMEN'S CLOTHING",price:99.99,oldPrice:124.99,rating:"★★★★★",reviews:53,badge:"-20%",newArrival:false,colors:["#c6ad91","#111"],image:"https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?auto=format&fit=crop&w=700&q=85",description:"A sophisticated coat with a relaxed fit and warm neutral tone."},
  {id:6,name:"Relaxed Hoodie",category:"men",label:"MEN'S CLOTHING",price:59.99,rating:"★★★★★",reviews:76,badge:"",newArrival:false,colors:["#222","#ddd","#8a6"],image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=700&q=85",description:"A soft, relaxed hoodie made for comfortable everyday styling."},
  {id:7,name:"Minimalist Top",category:"women",label:"WOMEN'S CLOTHING",price:39.99,rating:"★★★★☆",reviews:29,badge:"NEW",newArrival:true,colors:["#111","#fff","#caa"],image:"https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=700&q=85",description:"A minimal top that pairs effortlessly with your favorite pieces."},
  {id:8,name:"Classic White Sneakers",category:"shoes",label:"FOOTWEAR",price:79.99,rating:"★★★★★",reviews:94,badge:"",newArrival:false,colors:["#fff","#111"],image:"https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=700&q=85",description:"A clean sneaker designed to work with almost any outfit."},
  {id:9,name:"Leather Mini Bag",category:"accessories",label:"ACCESSORIES",price:69.99,rating:"★★★★★",reviews:36,badge:"NEW",newArrival:true,colors:["#111","#8a5"],image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=700&q=85",description:"A compact statement bag for polished everyday looks."},
  {id:10,name:"Classic Watch",category:"accessories",label:"ACCESSORIES",price:109.99,oldPrice:139.99,rating:"★★★★★",reviews:21,badge:"SALE",newArrival:false,colors:["#111","#c9a"],image:"https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=85",description:"A minimalist watch with a timeless finish."}
];

let cart = JSON.parse(localStorage.getItem("luxewear_cart") || "[]");
let wishlist = JSON.parse(localStorage.getItem("luxewear_wishlist") || "[]");
let activeFilter = "all";
let searchTerm = "";
let selectedProduct = null;
let modalQty = 1;
let selectedColor = null;

const $ = id => document.getElementById(id);
const money = n => `$${n.toFixed(2)}`;

function saveState(){
  localStorage.setItem("luxewear_cart", JSON.stringify(cart));
  localStorage.setItem("luxewear_wishlist", JSON.stringify(wishlist));
  updateHeaderCounts();
}

function updateHeaderCounts(){
  $("cartCount").textContent = cart.reduce((sum,i)=>sum+i.qty,0);
  $("wishlistCount").textContent = wishlist.length;
}

function productCard(p){
  const liked = wishlist.includes(p.id);
  return `<article class="product-card">
    <div class="product-image">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      ${p.badge ? `<span class="badge">${p.badge}</span>` : ""}
      <button class="favorite ${liked ? "active":""}" data-wish="${p.id}" aria-label="Wishlist">${liked ? "♥":"♡"}</button>
    </div>
    <div class="product-info">
      <p class="product-category">${p.label}</p>
      <h3>${p.name}</h3>
      <div class="rating">${p.rating} <span>(${p.reviews})</span></div>
      <div class="price">${money(p.price)} ${p.oldPrice ? `<del>${money(p.oldPrice)}</del>`:""}</div>
      <button class="add-cart" data-view="${p.id}">View Product</button>
    </div>
  </article>`;
}

function filteredProducts(){
  let list = products.filter(p => activeFilter==="all" || p.category===activeFilter);
  if(searchTerm) list = list.filter(p => `${p.name} ${p.category} ${p.label}`.toLowerCase().includes(searchTerm.toLowerCase()));
  const sort = $("sortProducts").value;
  if(sort==="price-low") list.sort((a,b)=>a.price-b.price);
  if(sort==="price-high") list.sort((a,b)=>b.price-a.price);
  if(sort==="name") list.sort((a,b)=>a.name.localeCompare(b.name));
  return list;
}

function renderProducts(){
  const list = filteredProducts();
  $("productGrid").innerHTML = list.map(productCard).join("");
  $("emptyState").hidden = list.length > 0;
}

function renderNew(){
  $("newGrid").innerHTML = products.filter(p=>p.newArrival).slice(0,4).map(productCard).join("");
}

function renderCart(){
  if(!cart.length){
    $("cartItems").innerHTML = `<div class="empty-state"><h3>Your cart is empty.</h3><p>Add something you love and it will appear here.</p></div>`;
  }else{
    $("cartItems").innerHTML = cart.map(item=>{
      const p=products.find(x=>x.id===item.id);
      return `<div class="cart-item">
        <img src="${p.image}" alt="${p.name}">
        <div><h4>${p.name}</h4><p>${item.size} · ${item.colorName}</p><strong>${money(p.price)}</strong>
          <div class="cart-actions"><button data-cart-minus="${p.id}">−</button><span>${item.qty}</span><button data-cart-plus="${p.id}">+</button><button class="remove" data-cart-remove="${p.id}">Remove</button></div>
        </div>
        <strong>${money(p.price*item.qty)}</strong>
      </div>`;
    }).join("");
  }
  const total=cart.reduce((sum,item)=>{const p=products.find(x=>x.id===item.id);return sum+p.price*item.qty},0);
  $("cartTotal").textContent=money(total);
  $("checkoutTotal").textContent=money(total);
}

function openOverlay(){
  $("modalBackdrop").classList.add("active");
  document.body.classList.add("no-scroll");
}
function closeAll(){
  document.querySelectorAll(".modal.open").forEach(m=>m.classList.remove("open"));
  $("cartDrawer").classList.remove("open");
  $("modalBackdrop").classList.remove("active");
  document.body.classList.remove("no-scroll");
}

function openProduct(id){
  selectedProduct=products.find(p=>p.id===id);
  modalQty=1;
  selectedColor=selectedProduct.colors[0];
  $("modalProductImage").src=selectedProduct.image;
  $("modalProductImage").alt=selectedProduct.name;
  $("modalProductCategory").textContent=selectedProduct.label;
  $("modalProductName").textContent=selectedProduct.name;
  $("modalProductRating").innerHTML=`${selectedProduct.rating} <span>(${selectedProduct.reviews})</span>`;
  $("modalProductPrice").innerHTML=`${money(selectedProduct.price)} ${selectedProduct.oldPrice?`<del>${money(selectedProduct.oldPrice)}</del>`:""}`;
  $("modalProductDescription").textContent=selectedProduct.description;
  $("modalQty").textContent=modalQty;
  $("modalColors").innerHTML=selectedProduct.colors.map((c,i)=>`<button class="swatch ${i===0?"active":""}" style="background:${c}" data-color="${c}" aria-label="Color ${i+1}"></button>`).join("");
  $("modalWishlist").textContent=wishlist.includes(id)?"♥ Remove from wishlist":"♡ Add to wishlist";
  $("productModal").classList.add("open"); openOverlay();
}

function addToCart(p, qty=1){
  const size=$("modalSize").value;
  const colorName=selectedColor || p.colors[0];
  const existing=cart.find(i=>i.id===p.id && i.size===size && i.colorName===colorName);
  if(existing) existing.qty+=qty;
  else cart.push({id:p.id,qty,size,colorName});
  saveState(); renderCart(); showToast(`${p.name} added to cart`);
}

function openCart(){
  renderCart(); $("cartDrawer").classList.add("open"); openOverlay();
}

function changeCart(id,delta){
  const item=cart.find(i=>i.id===id);
  if(!item)return;
  item.qty+=delta;
  if(item.qty<=0) cart=cart.filter(i=>i!==item);
  saveState(); renderCart();
}

function openAccount(){
  $("accountModal").classList.add("open"); openOverlay();
}

function showToast(msg){
  const t=$("toast"); t.textContent=msg; t.classList.add("show");
  clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>t.classList.remove("show"),2200);
}

document.addEventListener("click",e=>{
  const view=e.target.closest("[data-view]");
  if(view) openProduct(Number(view.dataset.view));

  const wish=e.target.closest("[data-wish]");
  if(wish){
    const id=Number(wish.dataset.wish);
    wishlist=wishlist.includes(id)?wishlist.filter(x=>x!==id):[...wishlist,id];
    saveState(); renderProducts(); renderNew();
    showToast(wishlist.includes(id)?"Added to wishlist":"Removed from wishlist");
  }

  const jump=e.target.closest("[data-category-jump]");
  if(jump){
    activeFilter=jump.dataset.categoryJump;
    document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));
    renderProducts();
    $("shop").scrollIntoView({behavior:"smooth"});
  }

  if(e.target.closest("[data-cart-plus]")) changeCart(Number(e.target.closest("[data-cart-plus]").dataset.cartPlus),1);
  if(e.target.closest("[data-cart-minus]")) changeCart(Number(e.target.closest("[data-cart-minus]").dataset.cartMinus),-1);
  if(e.target.closest("[data-cart-remove]")){
    const id=Number(e.target.closest("[data-cart-remove]").dataset.cartRemove);
    cart=cart.filter(i=>i.id!==id); saveState(); renderCart();
  }

  const color=e.target.closest("[data-color]");
  if(color){
    document.querySelectorAll(".swatch").forEach(s=>s.classList.remove("active"));
    color.classList.add("active"); selectedColor=color.dataset.color;
  }

  if(e.target.matches("[data-close]")) closeAll();
  if(e.target.id==="modalBackdrop") closeAll();

  const info=e.target.closest("[data-info]");
  if(info){e.preventDefault();showToast(`${info.dataset.info} page will be connected in the next store stage.`)}

  if(e.target.closest(".navigation a")) $("navigation").classList.remove("open");
});

document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  activeFilter=btn.dataset.filter;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===btn));
  renderProducts();
}));

$("sortProducts").addEventListener("change",renderProducts);
$("searchButton").addEventListener("click",()=>{$("searchArea").classList.toggle("active");$("searchInput").focus()});
$("closeSearch").addEventListener("click",()=>{$("searchArea").classList.remove("active");$("searchInput").value="";searchTerm="";renderProducts()});
$("searchInput").addEventListener("input",e=>{searchTerm=e.target.value;renderProducts()});
$("cartButton").addEventListener("click",openCart);
$("wishlistButton").addEventListener("click",()=>{
  activeFilter="all"; searchTerm="";
  $("searchInput").value="";
  $("shop").scrollIntoView({behavior:"smooth"});
  const liked=products.filter(p=>wishlist.includes(p.id));
  $("productGrid").innerHTML=liked.length?liked.map(productCard).join(""):`<div class="empty-state" style="grid-column:1/-1"><h3>Your wishlist is empty.</h3><p>Tap ♡ on a product to save it.</p></div>`;
});
$("accountButton").addEventListener("click",openAccount);
$("mobileMenuBtn").addEventListener("click",()=>$("navigation").classList.toggle("open"));

document.querySelector("[data-close]")?.addEventListener("click",closeAll);
document.querySelectorAll(".modal-close").forEach(b=>b.addEventListener("click",closeAll));

$("modalMinus").addEventListener("click",()=>{modalQty=Math.max(1,modalQty-1);$("modalQty").textContent=modalQty});
$("modalPlus").addEventListener("click",()=>{modalQty++;$("modalQty").textContent=modalQty});
$("modalAdd").addEventListener("click",()=>{if(selectedProduct)addToCart(selectedProduct,modalQty)});
$("modalWishlist").addEventListener("click",()=>{
  if(!selectedProduct)return;
  wishlist=wishlist.includes(selectedProduct.id)?wishlist.filter(x=>x!==selectedProduct.id):[...wishlist,selectedProduct.id];
  saveState(); $("modalWishlist").textContent=wishlist.includes(selectedProduct.id)?"♥ Remove from wishlist":"♡ Add to wishlist";
  renderProducts(); renderNew();
});

$("checkoutButton").addEventListener("click",()=>{
  if(!cart.length){showToast("Your cart is empty");return}
  renderCart(); $("checkoutModal").classList.add("open"); openOverlay();
});

$("checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();
  const orderNumber="LX"+Math.floor(100000+Math.random()*900000);
  cart=[]; saveState(); renderCart(); closeAll();
  $("successText").textContent=`Your order ${orderNumber} has been received. A confirmation will be sent to your email.`;
  $("successModal").classList.add("open"); openOverlay();
});

let accountMode="signin";
$("toggleAccount").addEventListener("click",()=>{
  accountMode=accountMode==="signin"?"signup":"signin";
  $("accountTitle").textContent=accountMode==="signin"?"Welcome back.":"Create your account.";
  $("accountSubmit").textContent=accountMode==="signin"?"Sign in":"Create account";
  $("accountName").hidden=accountMode==="signin";
  $("toggleAccount").textContent=accountMode==="signin"?"Create an account":"Already have an account? Sign in";
});
$("accountForm").addEventListener("submit",e=>{
  e.preventDefault();
  showToast(accountMode==="signin"?"Signed in (demo)":"Account created (demo)");
  closeAll();
});

$("newsletterForm").addEventListener("submit",e=>{
  e.preventDefault(); e.target.reset(); showToast("Thanks — you're on the LUXEWEAR list.");
});

$("saleButton").addEventListener("click",()=>{
  activeFilter="all"; document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter==="all"));
  $("shop").scrollIntoView({behavior:"smooth"});
  setTimeout(()=>{document.querySelectorAll(".product-card").forEach(card=>{if(!card.querySelector(".badge"))card.style.display="none"})},500);
});

const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add("visible")}),{threshold:.08});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

renderProducts();
renderNew();
renderCart();
updateHeaderCounts();
